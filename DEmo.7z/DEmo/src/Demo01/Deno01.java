package Demo01;

public class Deno01 {
public static void main(String[]args) {
	System.out.println("helloworld");
}
}
