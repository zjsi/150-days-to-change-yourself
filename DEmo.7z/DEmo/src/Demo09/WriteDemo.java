package Demo09;
import java.io.*; //��ʾ System.out.write().
public class WriteDemo {
	public static void main(String args[]) { 
		int b;
		b = 'A'; 
		System.out.write(b); 
		System.out.write('\n'); }
}
