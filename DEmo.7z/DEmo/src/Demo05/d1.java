package Demo05;

public interface d1 {
abstract void sd();
abstract void sdc();

String afe(String fs);
}
