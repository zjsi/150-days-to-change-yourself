package Demo05;
import java.lang.Character;
import java.util.Scanner;
public  class Demo05 extends DS {
public static void main(String[]args) {
	Demo05 d=new Demo05();
	d.afe("uiwrehw39iod0pop");
	d.sd();
	d.sdc();
}
	@Override
	public void sd() {
		// TODO Auto-generated method stub
		char[] helloArray = { 'r', 'u', 'n', 'o', 'o', 'b'};
		String helloString = new String(helloArray);
		System.out.print(helloArray);
	}

	@Override
	public void sdc() {
		// TODO Auto-generated method stub
		String site = "www.runoob.com"; int len = site.length(); 
		System.out.println( "����̳���ַ���� : " + len );
	}

	@Override
	public String afe(		String fs ) {
		
		return null;
		
		// TODO Auto-generated method stub

		
		
	}


}
