package Demo05;

abstract class DS implements d1 {

}
