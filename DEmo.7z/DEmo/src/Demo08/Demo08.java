package Demo08;
import java.util.*;
import java.util.regex.*; 
import java.util.Scanner;
interface df{
	abstract void jr();//�������󷽷�jr
	abstract void jdf();//�������󷽷�jdf
	}
abstract class hr implements df{
	
}
public class Demo08 extends hr {
public static void main(String[]args) {
	Scanner sc=new Scanner(System.in);
	Date da=new Date();
	System.out.println(da);
	String content = "I am noob " + "from runoob.com."; 
	String pattern = ".*runoob.*";
	boolean isMatch = Pattern.matches(pattern, content);
	System.out.println("�ַ������Ƿ������ 'runoob' ���ַ���? " + isMatch);

}

@Override
public void jr() {
	// TODO Auto-generated method stub

}


@Override
public void jdf() {
	// TODO Auto-generated method stub
	
}
}
