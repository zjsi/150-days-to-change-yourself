package Demo04;

public class Demo04 {
	int age=12;
	public static void main(String[]args) {
		Demo04 d=new Demo04();
	int x=d.age;
	byte A=(byte)x;
	System.out.println(A);
	}

}
