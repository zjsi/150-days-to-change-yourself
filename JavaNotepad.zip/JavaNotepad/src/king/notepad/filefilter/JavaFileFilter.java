package king.notepad.filefilter;

public class JavaFileFilter extends MyFileFilter {
    public JavaFileFilter(){
        super();
        addExtension("Java");
        addDescription("JavaԴ�����ļ�(*.java)");
    }
}
